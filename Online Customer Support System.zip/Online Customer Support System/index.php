<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support Services</title>
    <link rel="stylesheet" href="content/css/header_style.css">
    <link rel="stylesheet" href="content/css/Home_styles.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Support Desk</a></h1> <!-- Links to Home -->
            </div>
    
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </nav>
    
            <div class="search-bar">
                <input type="text" placeholder="How can we help you today?">
                <button>Search</button>
            </div>
    
            <div class="header-buttons">
                <a href="contact.html" class="btn-contact">Contact Support</a>
                <a href="login.html" class="btn-login">Sign in</a>
                <a href="register.html" class="btn-login">Sign up</a>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <main>
        <section class="hero-section">
            <div class="hero-container">
                <div class="hero-card">
                    <h3>Knowledgebase</h3>
                    <a href="#">View all articles</a> <!-- Link to knowledgebase -->
                </div>
                <div class="hero-card">
                    <h3>Files</h3>
                    <a href="#">Browse our files</a> <!-- Link to files -->
                </div>
                <div class="hero-card">
                    <h3>Contact Support</h3>
                    <a href="#">Get in touch for help</a> <!-- Link to contact -->
                </div>
            </div>
        </section>

        <section class="welcome-section">
            <h2>Welcome to Support Services</h2>
            <p>If you are seeking information, please type in the key words in the search bar above. If you wish to connect with us, please fill the Contact Us form. We are constantly updating this site to provide up-to-date services for you.</p>
        </section>

        <section class="knowledgebase-section">
            <h2>Knowledgebase</h2>
            <ul>
                <li><a href="#">About Us</a></li> <!-- Link to About Us -->
                <li><a href="#">Clubs and Societies</a></li> <!-- Link to Clubs -->
                <li><a href="#">Financial Aid / Scholarships</a></li> <!-- Link to Financial Aid -->
                <li><a href="#">Franchised Programs Documents Verification</a></li> <!-- Link to Documents Verification -->
                <li><a href="#">What is a 'phishing' email or an attack?</a></li> <!-- Link to Phishing Info -->
            </ul>
            <a href="knowledgebase.php">View all articles in General</a> <!-- Link to all articles -->
        </section>

                <!-- Feedback Section -->
                <div class="feedback-section">
                    <h2>User Feedback</h2>
                    <div class="feedback-list">
                        <?php
                            require 'db_conn.php';
        
                            // Query to fetch up to 4 random feedback entries
                            $sql = "SELECT feedback_text, date_submitted FROM feedback ORDER BY RAND() LIMIT 4";
                            $result = $conn->query($sql);
        
                            // Check if there are feedbacks to display
                            if ($result->num_rows > 0) {
                                // Loop through the results and display them
                                while ($row = $result->fetch_assoc()) {
                                    echo "<div class='feedback-item'>";
                                    echo "<p><strong>Feedback:</strong> " . htmlspecialchars($row['feedback_text']) . "</p>";
                                    echo "<p><small><strong>Date:</strong> " . htmlspecialchars($row['date_submitted']) . "</small></p>";
                                    echo "</div>";
                                }
                            } else {
                                echo "<p class='no-feedback'>No feedback available at the moment.</p>";
                            }
        
                            // Close the database connection
                            $conn->close();
                        ?>
                    </div>
                </div>
    </main>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Support Services. All rights reserved.</p>
    </footer>

</body>
</html>
