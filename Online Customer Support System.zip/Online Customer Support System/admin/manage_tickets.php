<?php
session_start();
include '../db_conn.php'; // Include your database connection file

// Fetch tickets from the database
$sql = "SELECT t.ticket_id , u.name AS user_name, t.subject, t.status 
        FROM tickets t 
        JOIN users u ON t.user_id = u.id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Tickets - Admin Dashboard</title>
    <link rel="stylesheet" href="content/css/manage_tickets.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Manage Tickets Section -->
    <section class="manage-tickets-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php" class="active">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php">Manage Contacts</a></li>
                    <li><a href="manage_services.php" >Manage Services</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Manage Tickets</h2>
                <table class="tickets-table">
                    <thead>
                        <tr>
                            <th>Ticket ID</th>
                            <th>User</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($ticket = $result->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?php echo htmlspecialchars($ticket['ticket_id']); ?></td>
                                    <td><?php echo htmlspecialchars($ticket['user_name']); ?></td>
                                    <td><?php echo htmlspecialchars($ticket['subject']); ?></td>
                                    <td><?php echo htmlspecialchars($ticket['status']); ?></td>
                                    <td>
                                        <a href="view_ticket.php?ticket_id=<?php echo $ticket['ticket_id']; ?>" class="btn-view">View</a>
                                        <a href="delete_ticket.php?ticket_id=<?php echo $ticket['ticket_id']; ?>" class="btn-delete">Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5">No tickets found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
