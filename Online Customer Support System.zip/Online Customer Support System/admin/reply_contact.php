<?php
require '../db_conn.php';

// Fetch contact details based on ID passed in the URL
$contact_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($contact_id > 0) {
    $sql = "SELECT * FROM contact_support WHERE id = $contact_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $contact = $result->fetch_assoc();
    } else {
        echo "<script>alert('No contact found with this ID.'); window.location.href='manage_contacts.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('Invalid contact ID.'); window.location.href='manage_contacts.php';</script>";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reply to Contact - Admin Dashboard</title>
    <link rel="stylesheet" href="content/css/reply_contact.css">
    <link rel="stylesheet" href="content/css/admin_dashboard.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Reply to Contact Section -->
    <section class="reply-contact-section">
        <div class="dashboard-container">
        <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php" class="active">Manage Contacts</a></li>
                    <li><a href="manage_services.php">Manage Services</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Reply to Contact</h2>
                <div class="contact-details">
                    <p><strong>ID:</strong> <?php echo $contact['id']; ?></p>
                    <p><strong>Name:</strong> <?php echo htmlspecialchars($contact['name']); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($contact['email']); ?></p>
                    <p><strong>Message:</strong> <?php echo htmlspecialchars($contact['message']); ?></p>
                </div>
                <form action="include/send_reply.php" method="POST" class="reply-form">
                    <input type="hidden" name="contact_id" value="<?php echo $contact['id']; ?>">
                    <textarea name="reply_message" rows="5" placeholder="Type your reply here..." required></textarea>
                    <button type="submit" class="btn-send">Send Reply</button>
                </form>
                <a href="manage_contacts.php" class="btn-back">Back to Manage Contacts</a>
            </div>
        </div>
    </section>

    <?php
    // Close the database connection
    $conn->close();
    ?>
</body>
</html>
