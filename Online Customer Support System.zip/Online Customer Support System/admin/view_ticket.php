<?php
session_start();
include '../db_conn.php'; 


if (isset($_GET['ticket_id'])) {
    $ticket_id = $_GET['ticket_id'];

    
    $sql = "SELECT t.ticket_id, u.name AS user_name, t.subject, t.description, t.status 
            FROM tickets t 
            JOIN users u ON t.user_id = u.id 
            WHERE t.ticket_id = '$ticket_id'";
    $result = $conn->query($sql);
    
    
    if ($result->num_rows > 0) {
        $ticket = $result->fetch_assoc();
    } else {
        echo "Ticket not found.";
        exit;
    }

    
    $message_sql = "SELECT m.message_id, m.sender_type, m.message, m.message_time 
                    FROM ticket_messages m 
                    WHERE m.ticket_id = '$ticket_id' 
                    ORDER BY m.message_time ASC";
    $message_result = $conn->query($message_sql);
} else {
    echo "No ticket ID provided.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Ticket - Admin Dashboard</title>
    <link rel="stylesheet" href="content/css/view_ticket.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- View Ticket Section -->
    <section class="view-ticket-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php" class="active">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php">Manage Contacts</a></li>
                    <li><a href="manage_services.php">Manage Services</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Ticket Details</h2>
                <div class="ticket-info">
                    <h3>Ticket ID: #<?php echo htmlspecialchars($ticket['ticket_id']); ?></h3>
                    <p><strong>User:</strong> <?php echo htmlspecialchars($ticket['user_name']); ?></p>
                    <p><strong>Subject:</strong> <?php echo htmlspecialchars($ticket['subject']); ?></p>
                    <p><strong>Description:</strong></p>
                    <p><?php echo nl2br(htmlspecialchars($ticket['description'])); ?></p>
                    <p><strong>Status:</strong> <?php echo htmlspecialchars($ticket['status']); ?></p>
                </div>

                <div class="ticket-messages">
                    <h3>Messages</h3>
                    <?php if ($message_result->num_rows > 0): ?>
                        <div class="message-list">
                            <?php while ($message = $message_result->fetch_assoc()): ?>
                                <div class="message <?php echo htmlspecialchars($message['sender_type']); ?>">
                                    <p><strong><?php echo htmlspecialchars(ucfirst($message['sender_type'])); ?>:</strong> <?php echo nl2br(htmlspecialchars($message['message'])); ?></p>
                                    <p class="message-time"><?php echo htmlspecialchars($message['message_time']); ?></p>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <p>No messages found for this ticket.</p>
                    <?php endif; ?>
                </div>

                <div class="reply-section">
                    <h3>Reply to Ticket</h3>
                    <form action="include/reply_ticket.php" method="POST">
                        <input type="hidden" name="ticket_id" value="<?php echo $ticket['ticket_id']; ?>">
                        <textarea name="reply" rows="5" placeholder="Type your reply here..." required></textarea>
                        <button type="submit" class="btn-reply">Send Reply</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

</body>
</html>

<?php
$conn->close(); 
?>
