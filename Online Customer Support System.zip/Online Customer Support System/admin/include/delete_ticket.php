<?php
session_start();
include '../../db_conn.php'; // Include your database connection file


if (isset($_POST['ticket_id'])) {
    $ticket_id = $_POST['ticket_id'];

    // Prepare the SQL statement to prevent SQL injection
    $sql = "DELETE FROM tickets WHERE ticket_id = '$ticket_id'";
    $sql1 = "DELETE FROM ticket_messages WHERE ticket_id = '$ticket_id'";

    if ($conn->query($sql) === TRUE && $conn->query($sql1) === TRUE) {
        echo "<script>alert('Ticket deleted successfully!'); window.location.href='../manage_tickets.php';</script>";
        exit;
    } else {
        echo "<script>alert('Error deleting ticket: " . $conn->error . "'); window.location.href='../manage_tickets.php';</script>";
    }
} else {
    echo "<script>alert('No ticket ID provided.'); window.location.href='../manage_tickets.php';</script>";
}


$conn->close();
?>
