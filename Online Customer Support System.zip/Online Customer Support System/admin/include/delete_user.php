<?php
session_start();
include '../../db_conn.php'; // Include your database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $confirm = $_POST['confirm'];

    // Check if the confirmation matches
    if (strtoupper($confirm) === "DELETE") {
        // Prepare the SQL statement to prevent SQL injection
        $sql = "DELETE FROM users WHERE id = '$user_id'";
    
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('User deleted successfully!'); window.location.href='../manage_users.php';</script>";
            exit;
        } else {
            echo "<script>alert('Error deleting user: " . $conn->error . "'); window.location.href='../manage_users.php';</script>";
        }
    } else {
        echo "<script>alert('Confirmation does not match. Please type \"DELETE\" to confirm.'); window.location.href='../manage_users.php';</script>";
    }
    
}

$conn->close();
?>
