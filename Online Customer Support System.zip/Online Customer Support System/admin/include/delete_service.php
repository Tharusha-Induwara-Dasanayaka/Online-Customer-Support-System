<?php
require '../../db_conn.php';

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the service ID from the form
    $service_id = $_POST['service_id'];



    // Delete the service
    $sql = "DELETE FROM services WHERE id = '$service_id'";

if ($conn->query($sql) === TRUE) {
    // Redirect to the manage services page after deletion with an alert
    echo "<script>alert('Record deleted successfully.'); window.location.href='../manage_services.php';</script>";
} else {
    echo "<script>alert('Error deleting record: " . $conn->error . "'); window.location.href='../manage_services.php';</script>";
}


    // Close the database connection
    $conn->close();
}

?>