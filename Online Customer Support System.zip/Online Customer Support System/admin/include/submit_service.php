<?php
require '../../db_conn.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $service_name = $_POST['service_name'];
    $price = $_POST['price'];
    $features = $_POST['features'];
    $status = $_POST['status'];

    // Handle image upload
    $image = $_FILES['image'];
    $image_path = "content/uploads/" . basename($image["name"]); // Set upload path

    // Move uploaded file to the designated folder
    if (move_uploaded_file($image["tmp_name"], '../' . $image_path)) {
        // Prepare SQL query
        $sql = "INSERT INTO services (service_name, image, price, features, status) 
                VALUES ('$service_name', '$image_path', '$price', '$features', '$status')";
    
        // Execute the query
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('New service added successfully!'); window.location.href='../manage_services.php';</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "'); window.location.href='../manage_services.php';</script>";
        }
    } else {
        echo "<script>alert('Error uploading image.'); window.location.href='../manage_services.php';</script>";
    }
    
}

// Close the database connection
$conn->close();
?>
