<?php
require '../../db_conn.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $service_id = $_POST['service_id'];
    $service_name = $_POST['service_name'];
    $price = $_POST['price'];
    $features = $_POST['features'];
    $status = $_POST['status'];

    // Handle image upload
    $image_path = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $image = $_FILES['image'];
        $image_path = "content/uploads/" . basename($image["name"]); // Set upload path

        // Move uploaded file to the designated folder
        if (!move_uploaded_file($image["tmp_name"], '../'.$image_path)) {
            echo "<script>alert('Error uploading image.'); window.location.href='../previous_page.php';</script>";
            exit;
        }

    }

    // Prepare SQL query
    if ($image_path) {
        // If a new image was uploaded, update the image path
        $sql = "UPDATE services SET service_name='$service_name', image='$image_path', price='$price', features='$features', status='$status' WHERE id='$service_id'";
    } else {
        // If no new image was uploaded, exclude the image field from the update
        $sql = "UPDATE services SET service_name='$service_name', price='$price', features='$features', status='$status' WHERE id='$service_id'";
    }

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Service updated successfully!'); window.location.href='../manage_services.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href='../manage_services.php';</script>";
    }
    
}

// Close the database connection
$conn->close();
?>
