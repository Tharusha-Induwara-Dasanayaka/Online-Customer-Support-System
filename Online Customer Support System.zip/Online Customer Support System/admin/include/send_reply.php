<?php
require '../../db_conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve the contact ID and reply message from the form
    $contact_id = isset($_POST['contact_id']) ? intval($_POST['contact_id']) : 0;
    $reply_message = isset($_POST['reply_message']) ? trim($_POST['reply_message']) : '';

    if ($contact_id > 0 && !empty($reply_message)) {
        // Update the contact_support table with the reply and current timestamp for reply_date
        $sql = "UPDATE contact_support 
                SET reply = '$reply_message', reply_date = NOW() 
                WHERE id = $contact_id";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Reply sent successfully.'); window.location.href='../manage_contacts.php';</script>";
            exit();
        } else {
            echo "<script>alert('Error updating record: " . $conn->error . "'); window.location.href='../manage_contacts.php';</script>";
        }
    } else {
        echo "<script>alert('Invalid contact ID or empty reply message.'); window.location.href='../manage_contacts.php';</script>";
    }
} else {
    echo "<script>alert('Invalid request method.'); window.location.href='../manage_contacts.php';</script>";
}


// Close the connection
$conn->close();
?>
