<?php
require '../../db_conn.php';

if (isset($_POST['contact_id'])) {
    $contact_id = intval($_POST['contact_id']);

    // Delete the contact from the database
    $sql = "DELETE FROM contact_support WHERE id = $contact_id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Contact deleted successfully.'); window.location.href='../manage_contacts.php';</script>";
    } else {
        echo "<script>alert('Error deleting contact: " . $conn->error . "'); window.location.href='../manage_contacts.php';</script>";
    }
} else {
    echo "<script>alert('Invalid request.'); window.location.href='../manage_contacts.php';</script>";
}
// Close the database connection
$conn->close();
?>
