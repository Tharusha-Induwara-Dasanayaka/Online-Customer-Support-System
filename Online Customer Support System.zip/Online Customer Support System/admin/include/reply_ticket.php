<?php
session_start();
include '../../db_conn.php'; // Include your database connection file

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ticket_id = $_POST['ticket_id']; // Get ticket_id from POST request
    $reply = $_POST['reply']; // Get the reply message from the form
    $sender_type = 'support'; // Set the sender type as 'support'

    // Escape the input to prevent SQL injection
    $ticket_id = $conn->real_escape_string($ticket_id);
    $reply = $conn->real_escape_string($reply);

    // Insert the reply into the ticket_messages table
    $sql = "INSERT INTO ticket_messages (ticket_id, sender_type, message, message_time) 
            VALUES ('$ticket_id', '$sender_type', '$reply', NOW())";

    $sql1 = "UPDATE tickets SET status = 'Pending' WHERE ticket_id = $ticket_id ";

if ($conn->query($sql) === TRUE && $conn->query($sql1) === TRUE ) {
    // Redirect to the view ticket page after successful insertion
    echo "<script>alert('Ticket updated successfully!'); window.location.href='../view_ticket.php?ticket_id=$ticket_id';</script>";
    exit();
} else {
    echo "<script>alert('Error: " . $conn->error . "'); window.location.href='../view_ticket.php';</script>";
}

}

$conn->close(); // Close the database connection
?>
