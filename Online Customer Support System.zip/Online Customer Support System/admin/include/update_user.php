<?php
session_start();
include '../../db_conn.php'; // Include your database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_POST['user_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $role = $_POST['role'];
    $status = $_POST['status'];

    // Use prepared statements to prevent SQL injection
    $sql = "UPDATE users SET name = '$name', email = '$email', role = '$role', status = '$status' WHERE id = '$user_id'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('User updated successfully!'); window.location.href='../manage_users.php';</script>";
    } else {
        echo "<script>alert('Error updating user: " . $conn->error . "'); window.location.href='../manage_users.php';</script>";
    }
    
}

$conn->close();
?>
