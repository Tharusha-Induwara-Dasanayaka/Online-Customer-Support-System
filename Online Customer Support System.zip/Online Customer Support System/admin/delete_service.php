<?php
require '../db_conn.php';

// Get the service ID from the URL (e.g., delete_service.php?service_id=1)
$service_id = $_GET['id'];

// Fetch the service data
$sql = "SELECT * FROM services WHERE id = '$service_id'";
$result = $conn->query($sql);
$service = $result->fetch_assoc();

// Check if the service exists
if (!$service) {
    die("Service not found.");
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Service</title>
    <link rel="stylesheet" href="content/css/admin_dashboard.css">
    <link rel="stylesheet" href="content/css/manage_services.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Delete Service Section -->
    <section class="delete-service-section">
        <div class="dashboard-container">
        <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php">Manage Contacts</a></li>
                    <li><a href="manage_services.php" class="active">Manage Services</a></li>
                </ul>
            </nav>

            <div class="dashboard-main">
                <h2>Delete Service</h2>
                <p>Are you sure you want to delete the following service?</p>
                
                <div class="service-details">
                    <h3>Service Name: <?php echo htmlspecialchars($service['service_name']); ?></h3> <!-- Service Name -->
                    <p>Description: <?php echo htmlspecialchars($service['features']); ?></p> <!-- Service Description -->
                </div>

                <form action="include/delete_service.php" method="POST">
                    <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>"> <!-- Service ID -->
                    <button type="submit" class="btn-delete">Delete Service</button>
                    <a href="manage_services.php" class="btn-cancel">Cancel</a>
                </form>
            </div>
        </div>
    </section>

</body>
</html>
