<?php
require '../db_conn.php';

// Get the service ID from the URL (e.g., edit_service.php?service_id=1)
$service_id = $_GET['id'];

// Fetch the service data
$sql = "SELECT * FROM services WHERE id = '$service_id'";
$result = $conn->query($sql);
$service = $result->fetch_assoc();

// Check if the service exists
if (!$service) {
    echo "<script>alert('Service not found.'); window.location.href='manage_services.php';</script>";
    exit;
}


// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Service</title>
    <link rel="stylesheet" href="content/css/admin_dashboard.css">
    <link rel="stylesheet" href="content/css/manage_services.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>
    <!-- Edit Service Section -->
    <section class="edit-service-section">
        <div class="dashboard-container">
        <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php">Manage Contacts</a></li>
                    <li><a href="manage_services.php" class="active">Manage Services</a></li>
                </ul>
            </nav>

            <div class="dashboard-main">
                <h2>Edit Service</h2>
                <form action="include/update_service.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="service_id" value="<?php echo $service['id']; ?>"> <!-- Service ID -->
                    <div class="form-group">
                        <label for="service_name">Service Name</label>
                        <input type="text" id="service_name" name="service_name" value="<?php echo htmlspecialchars($service['service_name']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="image">Image</label>
                        <input type="file" id="image" name="image" accept="image/*"> <!-- Image optional for update -->
                    </div>
                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="number" id="price" name="price" step="0.01" value="<?php echo htmlspecialchars($service['price']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="features">Features</label>
                        <textarea id="features" name="features" rows="5" required><?php echo htmlspecialchars($service['features']); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status" required>
                            <option value="active" <?php if ($service['status'] == 'active') echo 'selected'; ?>>Active</option>
                            <option value="inactive" <?php if ($service['status'] == 'inactive') echo 'selected'; ?>>Inactive</option>
                        </select>
                    </div>
                    <button type="submit" class="btn-submit">Update Service</button>
                    <a href="manage_services.php" class="btn-cancel">Cancel</a>
                </form>
            </div>
        </div>
    </section>

</body>
</html>
