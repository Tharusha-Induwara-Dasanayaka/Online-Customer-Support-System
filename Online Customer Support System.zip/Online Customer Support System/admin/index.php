<?php
require '../db_conn.php'; // Include database connection

// Fetch the total number of registered users
$sql_users = "SELECT COUNT(*) AS total_users FROM users"; // Replace 'users' with your actual users table name
$result_users = $conn->query($sql_users);
$total_users = $result_users->fetch_assoc()['total_users'];

// Fetch the total number of open tickets
$sql_tickets = "SELECT COUNT(*) AS open_tickets FROM tickets WHERE status = 'Open'"; // Replace 'tickets' with your actual tickets table name
$result_tickets = $conn->query($sql_tickets);
$total_open_tickets = $result_tickets->fetch_assoc()['open_tickets'];

// Fetch the total number of feedback submissions
$sql_feedback = "SELECT COUNT(*) AS total_feedback FROM feedback"; // Replace 'feedback' with your actual feedback table name
$result_feedback = $conn->query($sql_feedback);
$total_feedback = $result_feedback->fetch_assoc()['total_feedback'];

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Support Desk</title>
    <link rel="stylesheet" href="content/css/admin_dashboard.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Dashboard Container -->
    <section class="dashboard-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php" class="active">Overview</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php">Manage Contacts</a></li>
                    <li><a href="manage_services.php" >Manage Services</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Welcome, Admin</h2>
                <p>Here is an overview of the platform’s activity:</p>

                <div class="stats-grid">
                    <div class="stat-item">
                        <h3><?php echo $total_users; ?></h3>
                        <p>Registered Users</p>
                    </div>
                    <div class="stat-item">
                        <h3><?php echo $total_open_tickets; ?></h3>
                        <p>Open Tickets</p>
                    </div>
                    <div class="stat-item">
                        <h3><?php echo $total_feedback; ?></h3>
                        <p>Feedback Submissions</p>
                    </div>
                </div>

                <div class="admin-actions">
                    <h3>Quick Actions</h3>
                    <div class="action-grid">
                        <a href="manage_users.php" class="action-btn">Manage Users</a>
                        <a href="manage_tickets.php" class="action-btn">Manage Tickets</a>
                        <a href="manage_feedback.php" class="action-btn">Manage Feedback</a>
                        <a href="settings.php" class="action-btn">Platform Settings</a>
                    </div>
                </div>

            </div>
        </div>
    </section>

</body>
</html>
