<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Service</title>
    <link rel="stylesheet" href="content/css/admin_dashboard.css">
    <link rel="stylesheet" href="content/css/manage_services.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Add Service Section -->
    <section class="add-service-section">
        <div class="dashboard-container">
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php">Manage Contacts</a></li>
                    <li><a href="manage_services.php" class="active">Manage Services</a></li>
                </ul>
            </nav>

            <div class="dashboard-main">
                <h2>Add New Service</h2>
                <form action="include/submit_service.php" method="POST" enctype="multipart/form-data" id="serviceForm">
                    <div class="form-group">
                        <label for="service_name">Service Name</label>
                        <input type="text" id="service_name" name="service_name" >
                    </div>
                    <div class="form-group">
                        <label for="image">Image</label>
                        <input type="file" id="image" name="image" accept="image/*" >
                    </div>
                    <div class="form-group">
                        <label for="price">Price</label>
                        <input type="number" id="price" name="price" step="0.01" >
                    </div>
                    <div class="form-group">
                        <label for="features">Features</label>
                        <textarea id="features" name="features" rows="5" ></textarea>
                    </div>
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status" >
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                        </select>
                    </div>
                    <button type="submit" class="btn-submit">Add Service</button>
                    <a href="manage_services.php" class="btn-cancel">Cancel</a>
                </form>
            </div>
        </div>
    </section>

</body>
</html>


<script>
    document.querySelector('form[action="include/submit_service.php"]').addEventListener('submit', function(event) {
        const serviceName = document.querySelector('input[name="service_name"]').value.trim();
        const price = document.querySelector('input[name="price"]').value.trim();
        const features = document.querySelector('textarea[name="features"]').value.trim();
        const status = document.querySelector('select[name="status"]').value;

        if (!serviceName || !price || !features || !status) {
            alert('Please fill in all fields.');
            event.preventDefault();
            return;
        }

        if (isNaN(price) || price <= 0) {
            alert('Please enter a valid price.');
            event.preventDefault();
            return;
        }
    });
</script>
