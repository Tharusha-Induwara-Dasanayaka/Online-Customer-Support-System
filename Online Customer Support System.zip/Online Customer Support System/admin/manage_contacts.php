<?php
require '../db_conn.php';

// Fetch contacts data
$sql = "SELECT * FROM contact_support"; // Assuming 'contacts' is your table name
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Contacts - Admin Dashboard</title>
    <link rel="stylesheet" href="content/css/manage_contacts.css">
    <link rel="stylesheet" href="content/css/admin_dashboard.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Manage Contacts Section -->
    <section class="manage-contacts-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php" class="active">Manage Contacts</a></li>
                    <li><a href="manage_services.php" >Manage Services</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Manage Contacts</h2>
                <table class="contacts-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Message</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            // Output data of each row
                            while($row = $result->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td>" . $row["id"] . "</td>";
                                echo "<td>" . htmlspecialchars($row["name"]) . "</td>";
                                echo "<td>" . htmlspecialchars($row["email"]) . "</td>";
                                echo "<td>" . htmlspecialchars($row["message"]) . "</td>";
                                echo "<td>";
                                echo "<a href='view_contact.php?id=" . $row["id"] . "' class='btn-view'>View</a>";
                                echo "<a href='reply_contact.php?id=" . $row["id"] . "' class='btn-edit'>Reply</a>";
                                echo "<a href='delete_contact.php?id=" . $row["id"] . "' class='btn-delete'>Delete</a>";
                                echo "</td>";
                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='5'>No contacts found.</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <?php
    // Close the database connection
    $conn->close();
    ?>
</body>
</html>
