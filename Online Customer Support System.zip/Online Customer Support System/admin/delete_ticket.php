<?php
session_start();
include '../db_conn.php'; // Include your database connection file

// Get the ticket_id from the query string
if (isset($_GET['ticket_id'])) {
    $ticket_id = $_GET['ticket_id'];

    // Sanitize the ticket_id to prevent SQL injection
    $ticket_id = $conn->real_escape_string($ticket_id);

    // Fetch ticket details from the database
    $sql = "SELECT t.ticket_id, u.name AS user_name, t.subject, t.description, t.status 
            FROM tickets t 
            JOIN users u ON t.user_id = u.id 
            WHERE t.ticket_id = '$ticket_id'";
    $result = $conn->query($sql);
    
    // Check if the ticket exists
    if ($result->num_rows > 0) {
        $ticket = $result->fetch_assoc();
    } else {
        echo "<script>alert('Ticket not found.'); window.location.href='manage_tickets.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('No ticket ID provided.'); window.location.href='manage_tickets.php';</script>";
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Ticket - Admin Dashboard</title>
    <link rel="stylesheet" href="content/css/admin_dashboard.css">
    <link rel="stylesheet" href="content/css/delete_ticket.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Delete Ticket Section -->
    <section class="delete-ticket-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php" class="active">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php">Manage Contacts</a></li>
                    <li><a href="manage_services.php" >Manage Services</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Delete Ticket</h2>
                <div class="ticket-info">
                    <h3>Are you sure you want to delete this ticket?</h3>
                    <p><strong>Ticket ID:</strong> #<?php echo htmlspecialchars($ticket['ticket_id']); ?></p>
                    <p><strong>User:</strong> <?php echo htmlspecialchars($ticket['user_name']); ?></p>
                    <p><strong>Subject:</strong> <?php echo htmlspecialchars($ticket['subject']); ?></p>
                    <p><strong>Description:</strong> <?php echo htmlspecialchars($ticket['description']); ?></p>
                    <p><strong>Status:</strong> <?php echo htmlspecialchars($ticket['status']); ?></p>
                </div>
                <form action="include/delete_ticket.php" method="POST">
                    <input type="hidden" name="ticket_id" value="<?php echo htmlspecialchars($ticket['ticket_id']); ?>">
                    <button type="submit" class="btn-delete">Delete Ticket</button>
                    <a href="manage_tickets.php" class="btn-cancel">Cancel</a>
                </form>
            </div>
        </div>
    </section>

</body>
</html>

<?php
$conn->close(); // Close the database connection
?>
