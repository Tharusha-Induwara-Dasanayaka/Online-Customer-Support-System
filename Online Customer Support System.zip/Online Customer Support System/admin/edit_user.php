<?php
// edit_user.php
session_start();
include '../db_conn.php'; // Include your database connection file

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    $sql = "SELECT id, name, email, role, status FROM users WHERE id = '$user_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        echo "<script>alert('User not found.'); window.location.href='manage_users.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('No user ID provided.'); window.location.href='manage_users.php';</script>";
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - Admin Dashboard</title>
    <link rel="stylesheet" href="content/css/edit_user.css">
</head>
<body>
    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Edit User Section -->
    <section class="edit-user-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="manage_users.php" class="active">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php">Manage Contacts</a></li>
                    <li><a href="manage_services.php" >Manage Services</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Edit User</h2>

                <!-- User Details Form -->
                <form action="include/update_user.php" method="POST" class="edit-user-form">
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>"> <!-- Hidden field for User ID -->
                    <div class="form-group">
                        <label for="name">Full Name:</label>
                        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="role">Role:</label>
                        <select id="role" name="role" required>
                            <option value="customer" <?php echo ($user['role'] === 'customer') ? 'selected' : ''; ?>>Customer</option>
                            <option value="admin" <?php echo ($user['role'] === 'admin') ? 'selected' : ''; ?>>Admin</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="status">Status:</label>
                        <select id="status" name="status" required>
                            <option value="Active" <?php echo ($user['status'] === 'Active') ? 'selected' : ''; ?>>Active</option>
                            <option value="Inactive" <?php echo ($user['status'] === 'Inactive') ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>

                    <button type="submit" class="btn-save">Save Changes</button>
                </form>

            </div>
        </div>
    </section>
</body>
</html>
