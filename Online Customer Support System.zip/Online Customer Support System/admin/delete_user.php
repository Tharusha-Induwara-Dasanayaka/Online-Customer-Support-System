<?php
session_start();
include '../db_conn.php'; // Include your database connection file

if (isset($_GET['user_id'])) {
    $user_id = $_GET['user_id'];
    // Sanitize user_id to prevent SQL injection
    $user_id = $conn->real_escape_string($user_id);

    $sql = "SELECT name, email FROM users WHERE id = '$user_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
    } else {
        echo "<script>alert('User not found.'); window.location.href='manage_users.php';</script>";
        exit;
    }
} else {
    echo "<script>alert('No user ID provided.'); window.location.href='manage_users.php';</script>";
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete User - Admin Dashboard</title>
    <link rel="stylesheet" href="content/css/delete_user.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Admin Panel</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Dashboard</a></li>
                    <li><a href="manage_users.php">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Delete User Section -->
    <section class="delete-user-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="manage_users.php" class="active">Manage Users</a></li>
                    <li><a href="manage_tickets.php">Manage Tickets</a></li>
                    <li><a href="manage_contacts.php">Manage Contacts</a></li>
                    <li><a href="manage_services.php" >Manage Services</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Delete User</h2>
                <p>Are you sure you want to delete this user?</p>
                <p><strong>User Name: <?php echo htmlspecialchars($user['name']); ?></strong></p>
                <p><strong>Email: <?php echo htmlspecialchars($user['email']); ?></strong></p>

                <!-- Delete Confirmation Form -->
                <form action="include/delete_user.php" method="POST" class="delete-user-form">
                    <input type="hidden" name="user_id" value="<?php echo $user_id; ?>"> <!-- Hidden field for User ID -->
                    
                    <div class="form-group">
                        <label for="confirm">Type "DELETE" to confirm:</label>
                        <input type="text" id="confirm" name="confirm" placeholder="DELETE" required>
                    </div>

                    <button type="submit" class="btn-delete">Delete User</button>
                    <a href="manage_users.php" class="btn-cancel">Cancel</a>
                </form>
            </div>
        </div>
    </section>

</body>
</html>
