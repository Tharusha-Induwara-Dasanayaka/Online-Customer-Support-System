<?php
include 'db_conn.php'; // Include your database connection file

// Fetch active services from the database
$sql = "SELECT * FROM services WHERE status = 'active'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Our Services</title>
    <link rel="stylesheet" href="content/css/services_style.css">
    <link rel="stylesheet" href="content/css/header_style.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Support Desk</a></h1> <!-- Links to Home -->
            </div>
    
            <nav class="main-nav">
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
            </nav>
    
            <div class="search-bar">
                <input type="text" placeholder="How can we help you today?">
                <button>Search</button>
            </div>
    
            <div class="header-buttons">
                <a href="contact.html" class="btn-contact">Contact Support</a>
                <a href="login.html" class="btn-login">Sign in</a>
                <a href="register.html" class="btn-login">Sign up</a>
            </div>
        </div>
    </header>
    

    <!-- Services Section -->
    <section class="services-section">
        <h2 class="services-sectionh2">Our Services</h2>
        <div class="services-container">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($service = $result->fetch_assoc()): ?>
                    <div class="service-card">
                        <img src="admin/<?php echo $service['image']; ?>" alt="<?php echo $service['service_name']; ?>">
                        <h3><?php echo $service['service_name']; ?></h3>
                        <p>Price: $<?php echo number_format($service['price'], 2); ?></p>
                        <p>Features: <?php echo nl2br(htmlspecialchars($service['features'])); ?></p>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No services available at the moment.</p>
            <?php endif; ?>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 Support Services. All rights reserved.</p>
    </footer>

</body>
</html>
