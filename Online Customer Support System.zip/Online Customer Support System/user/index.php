<?php

session_start();
if (empty($_SESSION['id'])) {
    header("Location: ../login.html");
    exit();
}


$userName = $_SESSION['name'];


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard - Overview</title>
    <link rel="stylesheet" href="content/css/dashboard.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Support Desk</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../about.html">About</a></li>
                    <li><a href="../services.php">Services</a></li>
                    <li><a href="../contact.html">Contact</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Dashboard Container -->
    <section class="dashboard-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php" class="active">Overview</a></li>
                    <li><a href="profile.php">My Profile</a></li>
                    <li><a href="tickets.php">My Support Tickets</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="feedback.php" >Feedback</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Welcome, <?php echo htmlspecialchars($userName); ?></h2>
                <p>Here's a quick overview of your recent activity:</p>

                <div class="stats-grid">
                    <div class="stat-item">
                        <h3>5</h3>
                        <p>Open Tickets</p>
                    </div>
                    <div class="stat-item">
                        <h3>12</h3>
                        <p>Closed Tickets</p>
                    </div>
                    <div class="stat-item">
                        <h3>3</h3>
                        <p>Pending Responses</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

</body>
</html>
