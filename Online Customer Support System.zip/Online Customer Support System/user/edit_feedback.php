<?php
require '../db_conn.php';
session_start();

if (empty($_SESSION['id'])) {
    header("Location: ../login.html");
    exit();
}

// Fetch the feedback ID from the URL
if (isset($_GET['id'])) {
    $feedback_id = $_GET['id'];
    $user_id = $_SESSION['id'];

    // Fetch the current feedback details for this feedback ID
    $sql = "SELECT * FROM feedback WHERE id='$feedback_id' AND user_id='$user_id'";
    $result = $conn->query($sql);

    // If feedback found, get the feedback text
    if ($result->num_rows > 0) {
        $feedback = $result->fetch_assoc();
        $feedback_text = $feedback['feedback_text'];
    } else {
        // If no feedback found or it does not belong to this user
        echo "<script>alert('Invalid feedback ID or unauthorized access.'); window.location.href='feedback.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('No feedback ID specified.'); window.location.href='feedback.php';</script>";
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $updated_feedback = $_POST['feedback_text'];

    // Escape the input to prevent SQL injection
    $updated_feedback = $conn->real_escape_string($updated_feedback);

    // Update the feedback in the database
    $sql_update = "UPDATE feedback SET feedback_text='$updated_feedback', date_submitted=NOW() WHERE id='$feedback_id' AND user_id='$user_id'";

    if ($conn->query($sql_update) === TRUE) {
        echo "<script>alert('Feedback updated successfully.'); window.location.href='feedback.php';</script>";
    } else {
        echo "<script>alert('Error updating feedback: " . $conn->error . "'); window.history.back();</script>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Feedback - Support Desk</title>
    <link rel="stylesheet" href="content/css/dashboard.css">
    <link rel="stylesheet" href="content/css/edit_feedback.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Support Desk</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../about.html">About</a></li>
                    <li><a href="../services.php">Services</a></li>
                    <li><a href="../contact.html">Contact</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Feedback Container -->
    <section class="dashboard-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="profile.php">My Profile</a></li>
                    <li><a href="tickets.php">My Support Tickets</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="feedback.php" class="active">Feedback</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Feedback</h2>
                <p>We value your feedback! Let us know what you think about our service.</p>

                    <div class="edit-feedback-container">
                        <h2>Edit Feedback</h2>

                        <form action="edit_feedback.php?id=<?php echo $feedback_id; ?>" method="POST">
                            <label for="feedback-text">Edit your feedback</label>
                            <textarea id="feedback-text" name="feedback_text" rows="5"><?php echo htmlspecialchars($feedback_text); ?></textarea>
                            <button type="submit" class="btn-save">Save Changes</button>
                            <a href="feedback.php" class="btn-cancel">Cancel</a>
                        </form>
                    </div>
                    </div>
        </div>
    </section>

</body>
</html>


</body>
</html>
