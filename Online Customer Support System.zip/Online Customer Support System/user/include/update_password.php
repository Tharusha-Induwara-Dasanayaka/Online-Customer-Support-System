<?php
require '../../db_conn.php';

session_start();
if (empty($_SESSION['id'])) {
    header("Location: ../../login.html");
    exit();
}

$id = $_SESSION['id'];


$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];


if ($password !== $confirm_password) {
    echo "<script>alert('Passwords do not match.'); window.history.back();</script>";
    exit();
}


$hashed_password = password_hash($password, PASSWORD_BCRYPT);


$sql = "UPDATE users SET password='$hashed_password' WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
    
    echo "<script>alert('Password updated successfully.'); window.location.href='../profile.php';</script>";
} else {
    
    echo "<script>alert('Error updating password: " . $conn->error . "'); window.history.back();</script>";
}

$conn->close();
?>
