<?php
require '../../db_conn.php';
session_start();

// Check if the user is logged in
if (empty($_SESSION['id'])) {
    header("Location: ../../login.html");
    exit();
}

// Get the logged-in user ID and the ticket ID from the request
$user_id = $_SESSION['id'];
$ticket_id = isset($_POST['ticket_id']) ? $_POST['ticket_id'] : null;
$reply_message = isset($_POST['reply']) ? trim($_POST['reply']) : null;

if ($ticket_id && $reply_message) {
    // Insert the reply into the ticket_messages table
    $sql = "INSERT INTO ticket_messages (ticket_id, sender_type, message) 
            VALUES ('$ticket_id', 'user', '$reply_message')";

    if ($conn->query($sql) === TRUE) {
        // Success: Redirect back to the ticket view page with an alert
        echo "<script>alert('Reply submitted successfully.'); window.location.href='../view_ticket.php?id=$ticket_id&success=reply_submitted';</script>";
        exit();
    } else {
        // Error: Redirect back with an alert showing the error message
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href='../view_ticket.php?id=$ticket_id';</script>";
        exit();
    }
} else {
    // If there's an issue with the ticket or reply message, redirect with an error alert
    echo "<script>alert('Message cannot be empty.'); window.location.href='../view_ticket.php?id=$ticket_id&error=empty_message';</script>";
    exit();
}

$conn->close();
?>
