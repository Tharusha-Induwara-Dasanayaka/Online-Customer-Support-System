<?php
require '../../db_conn.php';

session_start();
if (empty($_SESSION['id'])) {
    header("Location: ../../login.html");
    exit();
}

$id = $_SESSION['id'];

// SQL query to delete the user account
$sql = "DELETE FROM users WHERE id='$id'";

// Execute the query
if ($conn->query($sql) === TRUE) {
    session_destroy(); // Destroy session after successful deletion
    echo "<script>alert('Account deleted successfully.'); window.location.href='../../login.html';</script>";
} else {
    // Show error message in case of failure
    echo "<script>alert('Error deleting account: " . $conn->error . "'); window.history.back();</script>";
}

$conn->close();
?>
