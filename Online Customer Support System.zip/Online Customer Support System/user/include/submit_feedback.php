<?php
require '../../db_conn.php';
session_start();

// Check if the user is logged in
if (empty($_SESSION['id'])) {
    header("Location: ../../login.html");
    exit();
}

// Get the user ID from the session and the feedback text from the form
$user_id = $_SESSION['id'];
$feedback_text = isset($_POST['feedback_text']) ? trim($_POST['feedback_text']) : null;

if ($feedback_text) {
    // Insert feedback into the database
    $sql = "INSERT INTO feedback (user_id, feedback_text) VALUES ('$user_id', '$feedback_text')";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Feedback submitted successfully.'); window.location.href='../feedback.php?success=feedback_submitted';</script>";
        exit();
    } else {
        echo "<script>alert('Error: " . $conn->error . "'); window.location.href='../feedback.php';</script>";
        exit();
    }
} else {
    // Redirect back with an error if feedback is empty
    echo "<script>alert('Feedback cannot be empty.'); window.location.href='../feedback.php?error=empty_feedback';</script>";
    exit();
}


$conn->close();
?>
