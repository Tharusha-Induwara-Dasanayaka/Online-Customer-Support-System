<?php
require '../../db_conn.php';

session_start();
if (empty($_SESSION['id'])) {
    header("Location: ../../login.html");
    exit();
}

$id = $_SESSION['id'];


$name = $_POST['name'];
$email = $_POST['email'];


$name = $conn->real_escape_string($name);
$email = $conn->real_escape_string($email);


$sql = "UPDATE users SET name='$name', email='$email' WHERE id='$id'";

if ($conn->query($sql) === TRUE) {
    $_SESSION['id'] = $id; 
    $_SESSION['name'] = $name; 
    echo "<script>alert('Account details updated successfully.'); window.location.href='../profile.php';</script>";
} else {
    
    echo "<script>alert('Error updating account details: " . $conn->error . "'); window.history.back();</script>";
}

$conn->close();
?>
