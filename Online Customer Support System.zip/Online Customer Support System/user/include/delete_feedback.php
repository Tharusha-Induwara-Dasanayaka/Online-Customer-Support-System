<?php
require '../../db_conn.php';
session_start();

// Check if the user is logged in
if (empty($_SESSION['id'])) {
    header("Location: ../../login.html");
    exit();
}

// Get the feedback ID from the request
$feedback_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($feedback_id) {
    // Delete the feedback from the database
    $sql = "DELETE FROM feedback WHERE id = '$feedback_id' AND user_id = '" . $_SESSION['id'] . "'";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Feedback deleted successfully.'); window.location.href='../feedback.php?success=feedback_deleted';</script>";
        exit();
    } else {
        echo "<script>alert('Error deleting feedback: " . $conn->error . "'); window.location.href='../feedback.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('No feedback ID provided.'); window.location.href='../feedback.php';</script>";
    exit();
}

$conn->close();
?>
