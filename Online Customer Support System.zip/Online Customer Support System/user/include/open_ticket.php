<?php
require '../../db_conn.php';

session_start();

// Ensure the user is logged in
if (empty($_SESSION['id'])) {
    header("Location: ../../login.html");
    exit();
}

$user_id = $_SESSION['id']; // Get the user ID from session
$subject = $_POST['subject'];
$description = $_POST['description'];

// Sanitize input to prevent SQL injection
$subject = $conn->real_escape_string($subject);
$description = $conn->real_escape_string($description);

// Insert ticket into the database
$sql = "INSERT INTO tickets (user_id, subject, description, status, created_at) VALUES ('$user_id', '$subject', '$description', 'Open', NOW())";

if ($conn->query($sql) === TRUE) {
    echo "<script>alert('Ticket opened successfully.'); window.location.href='../tickets.php';</script>";
    exit();
} else {
    echo "<script>alert('Error opening ticket: " . $conn->error . "'); window.location.href='../tickets.php';</script>";
    exit();
}

$conn->close();
?>
