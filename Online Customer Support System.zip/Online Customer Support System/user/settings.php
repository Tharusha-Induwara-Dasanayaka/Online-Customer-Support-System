<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Settings - Support Desk</title>
    <link rel="stylesheet" href="content/css/dashboard.css">
    <link rel="stylesheet" href="content/css/settings.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.html">Support Desk</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../about.html">About</a></li>
                    <li><a href="../services.php">Services</a></li>
                    <li><a href="../contact.html">Contact</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Settings Container -->
    <section class="dashboard-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="profile.php">My Profile</a></li>
                    <li><a href="tickets.php">My Support Tickets</a></li>
                    <li><a href="settings.php" class="active">Settings</a></li>
                    <li><a href="feedback.php" >Feedback</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>User Settings</h2>

                <!-- Settings Form -->
                <div class="settings-section">
                    <form action="update_settings.php" method="POST">
                        <h3>Update Preferences</h3>

                        <label for="email-notifications">Email Notifications</label>
                        <select id="email-notifications" name="email_notifications">
                            <option value="enabled">Enabled</option>
                            <option value="disabled">Disabled</option>
                        </select>

                        <label for="privacy">Privacy Settings</label>
                        <select id="privacy" name="privacy">
                            <option value="public">Public</option>
                            <option value="private">Private</option>
                        </select>

                        <button type="submit" class="btn-save">Save Changes</button>
                    </form>
                </div>

                <!-- Account Deletion Section -->
                <div class="account-deletion-section">
                    <h3>Delete Account</h3>
                    <p>Warning: Deleting your account is irreversible. All your data will be permanently deleted.</p>
                    <form action="include/delete_account.php" method="POST">
                        <button type="submit" class="btn-delete">Delete My Account</button>
                    </form>
                </div>

            </div>
        </div>
    </section>

</body>
</html>
