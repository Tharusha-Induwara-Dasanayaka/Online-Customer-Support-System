<?php
require '../db_conn.php';

session_start();
if (empty($_SESSION['id'])) {
    header("Location: ../login.html");
    exit();
}

$id = $_SESSION['id'];


$sql = "SELECT * FROM tickets WHERE user_id = '$id' ORDER BY last_updated DESC"; 
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Support Tickets - User Dashboard</title>
    <link rel="stylesheet" href="content/css/dashboard.css">
    <link rel="stylesheet" href="content/css/ticket.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.html">Support Desk</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../about.html">About</a></li>
                    <li><a href="../services.php">Services</a></li>
                    <li><a href="../contact.html">Contact</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Tickets Container -->
    <section class="dashboard-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="profile.php">My Profile</a></li>
                    <li><a href="tickets.php" class="active">My Support Tickets</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="feedback.php" >Feedback</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>My Support Tickets</h2>
                <p>Here are your current and past support tickets:</p>

                <!-- Tickets Table -->
                <table class="ticket-table">
                    <thead>
                        <tr>
                            <th>Ticket ID</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Last Updated</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result->num_rows > 0): ?>
                            <?php while ($ticket = $result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($ticket['ticket_id']); ?></td>
                                    <td><?php echo htmlspecialchars($ticket['subject']); ?></td>
                                    <td><span class="status <?php echo strtolower($ticket['status']); ?>"><?php echo htmlspecialchars($ticket['status']); ?></span></td>
                                    <td><?php echo htmlspecialchars($ticket['last_updated']); ?></td>
                                    <td><a href="view_ticket.php?id=<?php echo htmlspecialchars($ticket['ticket_id']); ?>" class="btn-view">View</a></td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5">No tickets found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Add Open New Ticket Button -->
                <div class="open-ticket-container">
                    <a href="open_ticket.php" class="btn-open-ticket">Open New Ticket</a>
                </div>
            </div>
        </div>
    </section>

</body>
</html>
