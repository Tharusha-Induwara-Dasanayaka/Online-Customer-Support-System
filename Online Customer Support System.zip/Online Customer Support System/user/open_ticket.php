<?php
require '../db_conn.php';

session_start();
if (empty($_SESSION['id'])) {
    header("Location: ../login.html");
    exit();
}

$id = $_SESSION['id'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Open a Ticket - User Dashboard</title>
    <link rel="stylesheet" href="content/css/dashboard.css">
    <link rel="stylesheet" href="content/css/open_ticket.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.html">Support Desk</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../about.html">About</a></li>
                    <li><a href="../services.php">Services</a></li>
                    <li><a href="../contact.html">Contact</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Tickets Container -->
    <section class="dashboard-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="profile.php">My Profile</a></li>
                    <li><a href="tickets.php" class="active">My Support Tickets</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="feedback.php" >Feedback</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Open a New Ticket</h2>
                <p>Submit your issue or query, and our support team will respond shortly.</p>

                <!-- Ticket Submission Form -->
                <form action="include/open_ticket.php" method="POST" id="ticketForm">
                    <div class="form-group">
                        <label for="subject">Subject</label>
                        <input type="text" id="subject" name="subject" >
                    </div>

                    <div class="form-group">
                        <label for="description">Description</label>
                        <textarea id="description" name="description" ></textarea>
                    </div>

                    <button type="submit" class="btn-submit">Submit Ticket</button>
                </form>
            </div>
        </div>
    </section>

</body>
</html>
<script>
    document.querySelector('form[action="include/open_ticket.php"]').addEventListener('submit', function(event) {
        const subject = document.querySelector('input[name="subject"]').value.trim();
        const description = document.querySelector('textarea[name="description"]').value.trim();

        if (!subject || !description) {
            alert('Please fill in all fields.');
            event.preventDefault();
            return;
        }
    });
</script>
