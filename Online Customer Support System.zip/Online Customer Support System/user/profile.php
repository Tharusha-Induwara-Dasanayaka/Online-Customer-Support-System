<?php

require '../db_conn.php';


session_start();
if (empty($_SESSION['id'])) {
    header("Location: ../login.html");
    exit();
}


$id = $_SESSION['id'];

// Query to retrieve user data
$sql = "SELECT * FROM users WHERE id = '$id'";
$result = $conn->query($sql);
$user_data = $result->fetch_assoc();

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - User Dashboard</title>
    <link rel="stylesheet" href="content/css/dashboard.css">
    <link rel="stylesheet" href="content/css/profile.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.html">Support Desk</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../about.html">About</a></li>
                    <li><a href="../services.php">Services</a></li>
                    <li><a href="../contact.html">Contact</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Account Container -->
    <section class="dashboard-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="profile.php"  class="active">My Profile</a></li>
                    <li><a href="tickets.php">My Support Tickets</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="feedback.php">Feedback</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>My Account</h2>
                <p>Manage your account details and password below:</p>

                <!-- Account Details Section -->
                <div class="account-section">
                    <h3>Account Details</h3>
                    <form class="account-form" action="include/update_account.php" method="POST">
                        <div class="form-group">
                            <label for="name">Full Name</label>
                            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user_data['name']); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required>
                        </div>

                        <button type="submit" class="btn-submit">Update Account Details</button>
                    </form>
                </div>

                <!-- Password Update Section -->
                <div class="password-section">
                    <h3>Password Update</h3>
                    <form class="password-form" action="include/update_password.php" method="POST">
                        <div class="form-group">
                            <label for="password">New Password</label>
                            <input type="password" id="password" name="password" placeholder="Enter new password" required>
                        </div>

                        <div class="form-group">
                            <label for="confirm-password">Confirm Password</label>
                            <input type="password" id="confirm-password" name="confirm_password" placeholder="Confirm new password" required>
                        </div>

                        <button type="submit" class="btn-submit">Update Password</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

</body>
</html>