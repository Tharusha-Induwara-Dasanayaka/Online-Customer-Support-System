<?php
require '../db_conn.php';

session_start();
if (empty($_SESSION['id'])) {
    header("Location: ../login.html");
    exit();
}

// Check if the ticket ID is provided in the URL
if (!isset($_GET['id'])) {
    echo "Ticket ID is missing.";
    exit();
}

$ticket_id = $_GET['id'];
$user_id = $_SESSION['id'];

// Fetch ticket details from the database without using bind_param
$sql = "SELECT * FROM tickets WHERE ticket_id = '$ticket_id' AND user_id = '$user_id'";
$ticket_result = $conn->query($sql);

if ($ticket_result->num_rows == 0) {
    // Use an alert to inform the user
    echo "<script>alert('Ticket not found or you don\\'t have permission to view this ticket.'); window.location.href='tickets.php';</script>";
    exit();
}


$ticket = $ticket_result->fetch_assoc();

// Fetch conversation/messages for the ticket
$sql_conversation = "SELECT * FROM ticket_messages WHERE ticket_id = '$ticket_id' ORDER BY message_time ASC";
$conversation_result = $conn->query($sql_conversation);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Support Ticket - User Dashboard</title>
    <link rel="stylesheet" href="content/css/dashboard.css">
    <link rel="stylesheet" href="content/css/ticket.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.html">Support Desk</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../about.html">About</a></li>
                    <li><a href="../services.php">Services</a></li>
                    <li><a href="../contact.html">Contact</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Ticket View Container -->
    <section class="dashboard-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="profile.php">My Profile</a></li>
                    <li><a href="tickets.php" class="active">My Support Tickets</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="feedback.php" >Feedback</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Support Ticket: #<?php echo htmlspecialchars($ticket['ticket_id']); ?></h2>
                <div class="ticket-details">
                    <p><strong>Subject:</strong> <?php echo htmlspecialchars($ticket['subject']); ?></p>
                    <p><strong>Status:</strong> <span class="status <?php echo strtolower($ticket['status']); ?>"><?php echo htmlspecialchars($ticket['status']); ?></span></p>
                    <p><strong>Created On:</strong> <?php echo htmlspecialchars($ticket['created_at']); ?></p>
                    <p><strong>Last Update:</strong> <?php echo htmlspecialchars($ticket['last_updated']); ?></p>
                </div>

                <!-- Ticket Conversation Section -->
                <div class="ticket-conversation">
                    <h3>Conversation</h3>
                    <?php if ($conversation_result->num_rows > 0): ?>
                        <?php while ($message = $conversation_result->fetch_assoc()): ?>
                            <div class="message <?php echo strtolower($message['sender_type']); ?>">
                                <p><strong><?php echo htmlspecialchars($message['sender_type'] === 'support' ? 'Support Team' : 'User'); ?>:</strong> <?php echo htmlspecialchars($message['message']); ?></p>
                                <span class="message-date"><?php echo htmlspecialchars($message['message_time']); ?></span>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p>No messages in this conversation yet.</p>
                    <?php endif; ?>
                </div>

                <!-- Reply Section -->
                <div class="reply-section">
                    <h3>Reply to this ticket:</h3>
                    <form action="include/submit_reply.php" method="POST">
                        <textarea name="reply" placeholder="Type your response..." rows="5" required></textarea>
                        <input type="hidden" name="ticket_id" value="<?php echo htmlspecialchars($ticket_id); ?>">
                        <button type="submit" class="btn-reply">Send Reply</button>
                    </form>
                </div>

            </div>
        </div>
    </section>

</body>
</html>
