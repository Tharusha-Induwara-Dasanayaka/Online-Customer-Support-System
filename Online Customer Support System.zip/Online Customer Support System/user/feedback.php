<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Feedback - Support Desk</title>
    <link rel="stylesheet" href="content/css/dashboard.css">
    <link rel="stylesheet" href="content/css/feedback.css">
</head>
<body>

    <!-- Header -->
    <header>
        <div class="header-container">
            <div class="logo">
                <h1><a href="index.php">Support Desk</a></h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../about.html">About</a></li>
                    <li><a href="../services.php">Services</a></li>
                    <li><a href="../contact.html">Contact</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Feedback Container -->
    <section class="dashboard-section">
        <div class="dashboard-container">
            <!-- Sidebar Navigation -->
            <nav class="sidebar">
                <ul>
                    <li><a href="index.php">Overview</a></li>
                    <li><a href="profile.php">My Profile</a></li>
                    <li><a href="tickets.php">My Support Tickets</a></li>
                    <li><a href="settings.php">Settings</a></li>
                    <li><a href="feedback.php" class="active">Feedback</a></li>
                </ul>
            </nav>

            <!-- Main Content -->
            <div class="dashboard-main">
                <h2>Feedback</h2>
                <p>We value your feedback! Let us know what you think about our service.</p>

                <!-- Feedback Form -->
                <div class="feedback-form">
                <form action="include/submit_feedback.php" method="POST" id="feedbackForm">
                    <label for="feedback-text">Your Feedback</label>
                        <textarea id="feedback-text" name="feedback_text" rows="5" placeholder="Enter your feedback here..." ></textarea>
                        <button type="submit" class="btn-submit">Submit Feedback</button>
                    </form>
                </div>

                <div class="feedback-list">
                    <h3>Your Past Feedback</h3>
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Feedback</th>
                                <th colspan=2>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            require '../db_conn.php';
                            session_start();
                
                            if (!empty($_SESSION['id'])) {
                                $user_id = $_SESSION['id'];
                                $sql = "SELECT * FROM feedback WHERE user_id = '$user_id' ORDER BY date_submitted DESC";
                                $result = $conn->query($sql);
                
                                if ($result->num_rows > 0) {
                                    while ($feedback = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>" . htmlspecialchars($feedback['date_submitted']) . "</td>";
                                        echo "<td>" . htmlspecialchars($feedback['feedback_text']) . "</td>";
                                        echo "<td><button class='btn-edit' data-id='" . $feedback['id'] . "'>Edit</button></td>";
                                        echo "<td><button class='btn-delete' data-id='" . $feedback['id'] . "'>Delete</button></td>";
                                        echo "</tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='3'>No feedback found.</td></tr>";
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
                

            </div>
        </div>
    </section>

</body>
</html>


<script>
document.querySelectorAll('.btn-edit').forEach(button => {
    button.addEventListener('click', function() {
        const feedbackId = this.getAttribute('data-id');
        if (confirm('Are you sure you want to edit this feedback?')) {
            window.location.href = `edit_feedback.php?id=${feedbackId}`;
        }
    });
});

document.querySelectorAll('.btn-delete').forEach(button => {
    button.addEventListener('click', function() {
        const feedbackId = this.getAttribute('data-id');
        if (confirm('Are you sure you want to delete this feedback?')) {
            window.location.href = `include/delete_feedback.php?id=${feedbackId}`;
        }
    });
});
</script>

<script>
    document.querySelector('form[action="include/submit_feedback.php"]').addEventListener('submit', function(event) {
        const feedback = document.querySelector('textarea[name="feedback_text"]').value.trim();

        if (!feedback) {
            alert('Please enter your feedback.');
            event.preventDefault();
            return;
        }
    });
</script>

