<?php
require '../db_conn.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    
    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        
        if (password_verify($password, $user['password'])) {
            session_start();
            $_SESSION['id'] = $user['id']; 
            $_SESSION['name'] = $user['name']; 
            
            
            if ($user['role'] === 'admin') {
                echo "<script>alert('Login successful! Redirecting to admin dashboard.'); window.location.href = '../admin/index.php';</script>";
            } else {
                echo "<script>alert('Login successful! Redirecting to user dashboard.'); window.location.href = '../user/index.php';</script>";
            }
        } else {
            
            echo "<script>alert('Invalid password. Please try again.'); window.location.href = '../login.html';</script>";
        }
    } else {
        
        echo "<script>alert('No account found with that email.'); window.location.href = '../login.html';</script>";
    }
}


$conn->close();
?>