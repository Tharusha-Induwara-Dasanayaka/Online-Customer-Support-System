<?php
require '../db_conn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm-password'];

    
    if ($password !== $confirm_password) {
        echo "<script>alert('Passwords do not match. Please try again.'); window.location.href = '../register.html';</script>";
        exit;
    }

    
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    
    $sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$hashed_password')";

    
    if ($conn->query($sql) === TRUE) {
        
        echo "<script>
                alert('Registration successful! You can now log in.');
                window.location.href = '../login.html';
              </script>";
    } else {
        echo "<script>
                alert('Registration failed!');
                window.location.href = '../register.html';
              </script>";
    }
}


$conn->close();
?>