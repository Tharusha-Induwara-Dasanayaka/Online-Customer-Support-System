<?php

require '../db_conn.php';


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $message = $conn->real_escape_string($_POST['message']);

    
    $sql = "INSERT INTO contact_support (name, email, message) VALUES ('$name', '$email', '$message')";

    
    if ($conn->query($sql) === TRUE) {
        // Success message and redirect
        echo "<script>
                alert('Message sent successfully!');
                window.location.href = '../contact.html'; 
              </script>";
    } else {
        echo "<script>
                alert('Message sending Failed!');
                window.location.href = '../contact.html'; 
              </script>";
    }
}


$conn->close();
?>